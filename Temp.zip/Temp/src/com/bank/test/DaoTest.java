package com.bank.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bank.bean.Customer;
import com.bank.bean.Passbook;
import com.bank.dao.DaoImpl;
import com.bank.dao.DaoInter;
import com.bank.exceprtion.CustomerNotFound;

public class DaoTest {
	DaoInter daoimpl;
	

	@Before
	public void setUp() throws Exception {
		 daoimpl=new DaoImpl();
		
		
	}

	@After
	public void tearDown() throws Exception {
		 daoimpl=null;
		
	}

	@Test
	public void testAddCustomer() throws CustomerNotFound {
		 Customer c=new Customer("Gnani","gnani@gmail.com","hyd,tel","9553075484","ABCDE1234F",20,12345678,1098,0);

		 daoimpl.addCustomer(c);
			
assertNotNull(c);
//assertEquals("Gnani",c.getName());
	}

	@Test
	public void testDeposit() throws CustomerNotFound {
		//fail("Not yet implemented");
		Passbook passbook=new Passbook(1,41104,"deposited amount is 500");
		Customer c=new Customer("Gnani","gnani@gmail.com","hyd,tel","9553075484","ABCDE1234F",20,12345678,1098,0);
	boolean b=daoimpl.deposit(c,passbook);
	assertEquals(false,b);
	
	}

	@Test
	public void testWithdraw() throws CustomerNotFound {
		//fail("Not yet implemented");
		Passbook passbook=new Passbook(1,41104,"withdrawn amount is 1000");
		Customer c=new Customer("Gnani","gnani@gmail.com","hyd,tel","9553075484","ABCDE1234F",20,12345678,1098,0);
	boolean b=daoimpl.withdraw(c,passbook);
	assertEquals(false,b);
	}

	@Test
	public void testShowBalance() throws CustomerNotFound {
		//fail("Not yet implemented");
		Double b=daoimpl.showBalance(41104);
		assertNotEquals(14650,b);
	}

	@Test
	public void testFundTransfer() throws CustomerNotFound {
		//fail("Not yet implemented");
		Customer c=new Customer("Gnani","gnani@gmail.com","hyd,tel","9553075484","ABCDE1234F",20,12345678,1098,0);
		Customer c1=new Customer("Gnan","gnan@gmail.com","hyd,tel","9989211447","ABCDE1234F",20,12345678,1098,0);
		Passbook passbook=new Passbook(1,41104,"withdrawn amount is 1000");
	boolean b=daoimpl.fundTransfer(c,c1,passbook);
	assertSame("Fund Transfer Unsuccessful",false,b);
	}

	@Test
	public void testPrintTransaction() throws CustomerNotFound {
		//fail("Not yet implemented");
		Customer c=new Customer("Gnani","gnani@gmail.com","hyd,tel","9553075484","ABCDE1234F",20,12345678,1098,0);
		List<Passbook> passbookList=daoimpl.printTransaction(12345678);
		assertEquals(12345678,c.getAccNumber());

}
}
