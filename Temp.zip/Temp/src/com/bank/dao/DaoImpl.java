package com.bank.dao;

/*import java.util.HashMap;
import java.util.Map;*/
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.bank.bean.Customer;
import com.bank.bean.Passbook;
import com.bank.exceprtion.CustomerNotFound;
import com.bank.util.JPAUtil;
public class DaoImpl implements DaoInter {
	
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("Temp"); 


	
	//Passbook passbook=new Passbook();
	//Scanner sc= new Scanner(System.in);
	//int wd = sc.nextInt();
//	Map<String,Customer> m=new HashMap<String,Customer>();
	//Customer c = new Customer();
	//Customer c1 = new Customer();
	
	public boolean addCustomer(Customer customer) throws CustomerNotFound  {
		// TODO Auto-generated method stub
		boolean flag=false;
		
	EntityManager entityManager = factory.createEntityManager(); 
	
		try
		{
			//entityManager=JPAUtil.getEntityManager();
			
			entityManager.getTransaction().begin();
			//transaction.begin();
			
			//employee.setEmpid(null);
			entityManager.persist(customer);
			flag=true;
			entityManager.flush();
			entityManager.getTransaction().commit();	
			//transaction.commit();
			
		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file
		
				throw new CustomerNotFound(e.getMessage());
		
		}
		finally 
		{
			entityManager.close();
		}
		return flag;
		
	}

	/*@Override
	public int withDraw(Customer c,int wblance) {
		wblance=(int) (c.getCurrBal()-wblance);
		c.setCurrBal(wblance);
		return (int) c.getCurrBal();
	}*/
	/*public void display(){
		System.out.println(m.get(c.getEmailId()));
	}

	

	@Override
	public boolean validAccountNo(String email,int accNumber,int pin)
	{
		System.err.println(c);
		boolean flag=false;
		for(Customer cust:m.values())
		{
			System.out.println(m.values());
			System.out.println(cust.getEmailId());
			System.out.println(cust.getAccNumber());
			System.out.println(cust.getPin());
			if((cust.getEmailId().equals(email))&&(cust.getAccNumber()==accNumber)&&(cust.getPin()==pin))
			{
				
				flag= true;
			}
		}
		
		return flag;
		
	}
	public Customer displayCust(int accNumber)
	{
		Customer cust=null;
		for (Customer c:m.values()) {
			if(c.getAccNumber()==accNumber)
					{
				cust=c;
					}
		}return cust;
		
	}

	

			
	
	@Override
	public int showBalance(Customer c,int accNumber1) {
		int am=0;
		for(Customer c1:m.values())
		{
	
		 am=(int)c1.getCurrBal();
	}
		return am;
}
	public boolean verifyAcc(String email4, int accNumber4)
	{
		boolean flag=false;
		for(Customer c:m.values())
		{
			if(c.getEmailId()==email4 || c.getAccNumber()==accNumber4)
			{
				flag= true;
				
			
			}
		
	}
		return flag;
	
}

	@Override
	public boolean fundTransfer(String email3, int accNumber3, int pin3, Customer a, Customer b, String email4,
			int accNumber4, int amount) {
		// TODO Auto-generated method stub
		boolean flag=false;	
		if((a.getEmailId()==email3)&&(a.getAccNumber()==accNumber3) && (a.getPin()==pin3))
		{
			if((b.getAccNumber()==accNumber4)&&(b.getEmailId()==email4))
			{
				if((a.getCurrBal()>amount))
				{
				int balc=0;
				int balc1=0;
				balc=a.getAccNumber()-amount;
				balc1=b.getAccNumber()+amount;
				a.setCurrBal(balc);
				b.setCurrBal(balc1);
				flag=true;
				}
			}
		
	}
		return flag;
	}
*/
	public boolean validatedeposit(int deposit) {
		// TODO Auto-generated method stub
		boolean flag=false;
	
		if(deposit>=0)
		{
			flag=true;
		}
	
	return flag;

	}

	/*@Override
	public void updateCustomer(Customer c,int amount) throws CustomerNotFound {
		// TODO Auto-generated method stub

		try
		{
			entityManager=JPAUtil.getEntityManager();
			//entityManager =Persistence.createEntityManagerFactory("JPACRUDProject").createEntityManager();
			entityManager.getTransaction().begin();

			//double amount=c.getCurrBal()+deposit(null, 0);
			c.setCurrBal(amount);
			entityManager.merge(c);// here that object becomes persistence object
			entityManager.getTransaction().commit();			
		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound (e.getMessage());
		}
		finally 
		{
		
			entityManager.close();
		}
		
	}*/

	@Override
	public Customer getCustomerDetails(int accNumber2, String email, int pin)
			throws CustomerNotFound {
		// TODO Auto-generated method stub
		EntityManager entityManager = factory.createEntityManager(); 

		try
		{
			
			Customer customer=entityManager.find(Customer.class,accNumber2);
			return customer ;
						
		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}
		finally 
		{
			entityManager.close();
		}
	}

	
	@Override
	public boolean deposit(Customer customer,Passbook passbook)
			throws CustomerNotFound {
		boolean flag=false;
		EntityManager entityManager = factory.createEntityManager(); 
		try
		{
			
			entityManager.getTransaction().begin();
			
			
			//System.out.println(amount);
			entityManager.merge(customer);
	
		    entityManager.merge(passbook);
			
			flag=true;
			//entityManager.flush();
			entityManager.getTransaction().commit();
		
				
		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file
			
		}
		finally 
		{
			entityManager.close();
		}
		
		// TODO Auto-generated method stub
		return flag;
	}

	@Override
	public boolean validateAmount(Double withdraw) {
		// TODO Auto-generated method stub
		boolean flag=false;
		if(withdraw>0)
		{
			flag=true;
			
		}
		
		return flag;
	}

	@Override
	public boolean withdraw(Customer cust,Passbook passbook) throws CustomerNotFound {
		// TODO Auto-generated method stub
		boolean flag=false;
		EntityManager entityManager = factory.createEntityManager(); 
		try
		{
			
			entityManager.getTransaction().begin();
			/*Customer customer1=entityManager.find(Customer.class,accNumber);
		
			Double amount=customer1.getCurrBal()-withdraw;
			customer1.setCurrBal(amount);
			System.out.println(amount);*/
			entityManager.merge(cust);
			entityManager.persist(passbook);
			entityManager.flush();
			entityManager.getTransaction().commit();
			flag=true;
			
		
				
		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file
			
		}
		finally 
		{
			entityManager.close();
		}
		
		// TODO Auto-generated method stub
		return flag;
	}

	@Override
	public boolean verifyDetails(String email1, int accNumber1, int pin1)
			throws CustomerNotFound {
		// TODO Auto-generated method stub
		boolean flag=false;
		EntityManager entityManager = factory.createEntityManager(); 
		try
		{
			
			entityManager.getTransaction().begin();
			Customer customer1=entityManager.find(Customer.class,accNumber1);
			if((customer1.getPin()==pin1) &&(customer1.getEmailId().equals(email1)) &&(customer1.getAccNumber()==accNumber1))
			{
			
			flag=true;
			}
		}
		
				
		
		finally 
		{
			entityManager.close();
		}
		return flag;
	}

	@Override
	public Double showBalance(int accNumber1) throws CustomerNotFound {
		// TODO Auto-generated method stub
		Customer customer1=null;EntityManager entityManager = factory.createEntityManager(); 
		try
		{
			//entityManager.getTransaction().begin();
			customer1=entityManager.find(Customer.class,accNumber1);
			
		
				
		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file
			
		}
		finally 
		{
			entityManager.close();
		}
		return customer1.getCurrBal();
	}

	@Override
	public boolean verifyAccno(int accNumber4,String email4) throws CustomerNotFound {
		// TODO Auto-generated method stub
		boolean flag=false;
		EntityManager entityManager = factory.createEntityManager(); 
		try
		{
			
			entityManager.getTransaction().begin();
			Customer customer1=entityManager.find(Customer.class,accNumber4);
			if((customer1.getEmailId().equals(email4)) &&(customer1.getAccNumber()==accNumber4))
			{
			
			flag=true;
			}
		
				
		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file
			
		}
		finally 
		{
			entityManager.close();
		}
		return flag;
	}

	@Override
	public boolean fundTransfer(Customer customer1,Customer customer2,Passbook passbook)
			throws CustomerNotFound {
		// TODO Auto-generated method stub
		boolean flag=false;
		EntityManager entityManager = factory.createEntityManager(); 
		try
		{
			entityManager.getTransaction().begin();
			
		
			entityManager.merge(customer1);
			entityManager.merge(customer2);
			entityManager.persist(passbook);
			//entityManager.persist(passbook);
			entityManager.flush();
			entityManager.getTransaction().commit();
			flag=true;
				}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file
			
		}
		finally 
		{
			entityManager.close();
		}
		return flag;
	}

	
		@Override
		public List<Passbook> printTransaction(int accountNumber) throws  CustomerNotFound {
			EntityManager entityManager = factory.createEntityManager(); 
			try
			{
			
				Query query=entityManager.createQuery("from Passbook where accNumber=?");
				query.setParameter(1, accountNumber);
				List<Passbook> passbookList=query.getResultList();
				return passbookList;
			}
			catch(PersistenceException e)
			{
				//TODO: Log to file
				e.printStackTrace();
				throw new CustomerNotFound(e.getMessage());
			}
			finally
			{
				entityManager.close();
			}
		}

		@Override
		public Customer getCust(int accNumber) throws CustomerNotFound {
			// TODO Auto-generated method stub
			EntityManager entityManager = factory.createEntityManager(); 
			try
			{
				
				Customer customer=entityManager.find(Customer.class,accNumber);
				return customer ;
							
			}
			catch(PersistenceException e) 
			{
				e.printStackTrace();
				//TODO: Log to file
				throw new CustomerNotFound(e.getMessage());
			}
			finally 
			{
				entityManager.close();
			}
		}


		// TODO Auto-generated method stub
		
	}

	



